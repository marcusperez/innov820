﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Paylocity.Web.Models
{
    public class PersonViewModel
    {
    }
}